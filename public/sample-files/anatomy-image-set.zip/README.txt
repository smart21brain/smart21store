Sample anatomy image set for Smart21Store testing. Replace with real images.
