Sample map pack for Smart21Store testing.
