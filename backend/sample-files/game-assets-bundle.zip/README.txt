Sample game assets for Smart21Store testing.
