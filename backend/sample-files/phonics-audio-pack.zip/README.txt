Sample file for Smart21Store testing.
