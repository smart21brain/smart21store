Sample circuit library for Smart21Store testing.
