Sample coding starter for Smart21Store testing.
