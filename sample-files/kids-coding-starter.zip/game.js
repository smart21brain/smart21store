// Starter: move the square with the arrow keys
let x=0;addEventListener("keydown",e=>{if(e.key=="ArrowRight")x+=10;console.log(x)});
