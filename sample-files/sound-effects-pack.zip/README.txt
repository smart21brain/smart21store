Sample sound effects for Smart21Store testing.
